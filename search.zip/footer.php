<!-- footer.php -->
<footer>
    <hr>
    <p>&copy; 2025 Lazy Chef </p>
</footer>
</body>

</html>