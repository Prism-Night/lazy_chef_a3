<!-- welcome.php -->

<section class="banner">
    <h2 class="hero"> Discover delicious recipes,<br>
        plan your meals and <br>
        simplfy cooking</h2>
    <img src="img/banner-welcome.jpg" alt="" class="welcome-banner">
</section>