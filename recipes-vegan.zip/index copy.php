<!-- index.php  -->
<!DOCTYPE html>
<html lang="en">


<?php

// Enable error reporting (for development only)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include necessary files
include('db_connect.php');
include('session-check.php');

?>

<!-- head.php  -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Website needs to be adaptive; using device width -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SEO Meta Tags -->
    <meta name="description" content="Lazy Chef - Quick and easy recipes for every occasion.">
    <meta name="keywords" content="recipes, cooking, food, quick meals, healthy recipes">
    <meta name="author" content="Lazy Chef">
    <!-- Title -->
    <title>Lazy Chef | Quick and Easy Recipes</title>
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="img/logo.png">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <!-- header.php  -->
    <header class="main-head">
        <nav class="HBmenu">
            <label for="toggle" aria-label="Toggle Menu" aria-expanded="false" aria-controls="menu-header">&#9776;</label>
            <input type="checkbox" id="toggle">
            <ul class="menu-header" id="menu-header">
                <li><a href="index.php">Home</a></li>
                <li><a href="recipes-a-main.php">Recipes</a>
                    <ul class="dropdown">
                        <li><a href="recipes-most-recent.php">Most Recent</a></li>
                        <li><a href="recipes-top-rated.php">Top Rated</a></li>
                        <li><a href="recipes-favorite.php" class="disabled">Favorite</a></li>
                        <li><a href="recipes-Cuisine.php">Cuisine</a></li>
                        <li><a href="recipes-vegan.php">Vegan</a></li>
                    </ul>
                </li>
                <li><a href="meals-a-main.php">Meals</a>
                    <ul class="dropdown">
                        <li><a href="meals-breakfast.php">Breakfast</a></li>
                        <li><a href="meals-main-course.php">Main Course</a></li>
                        <li><a href="meals-snacks.php">Snacks</a></li>
                        <li><a href="meals-desserts.php">Desserts</a></li>
                    </ul>
                </li>
                <li><a href="about-us.php">About</a></li>
                <li><a href="user-profile.php">User</a>
                    <ul class="dropdown">
                        <li><a href="#registerPopup">Registration</a></li>
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <!-- Logged-in user options -->
                            <li><a href="user-profile.php">Account</a></li>
                            <li><a href="logout.php">Logout</a></li>
                        <?php else: ?>
                            <!-- Guest user options -->
                            <li><a href="login.php">Login</a></li>
                            <li><a href="register.php">Register</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
        </nav>

        <div class="branding">
            <a href="index.php">
                <img src="img/logo.png" alt="Lazy Chef Logo" class="logo-image">
            </a>
            <h1><a href="index.php" class="lazyhead">Lazy Chef</a></h1>
        </div>

        <div class="search-container">
            <form action="search.php" method="get" class="search-bar">
                <label for="searchQuery" class="visually-hidden">Search</label>
                <input type="text" name="search" placeholder="Search . . . " required value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                <button type="submit" class="search-button">Search</button>
            </form>
        </div>

        <div class="login-container">
            <?php if (isset($_SESSION['user_id'])): ?>
                <!-- User is logged in -->
                <a href="logout.php" class="login-link">
                    <img src="img/logout-icon.png" alt="Logout" class="logout-icon">
                    <span>Logout</span>
                </a>
            <?php else: ?>
                <!-- User is not logged in -->
                <a href="#loginPopup" class="login-link">
                    <img src="img/login-icon.png" alt="Login" class="login-icon">
                    <span>Login</span>
                </a>
            <?php endif; ?>
        </div>

        <!-- Login Popup -->
        <section id="loginPopup" class="popup">
            <div class="popup-content">
                <a href="#" class="close" aria-label="Close_Popup">&times;</a>
                <form class="form" action="login.php" method="POST">
                    <h2>Login</h2>
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" class="popup-button">Login</button>
                </form>
            </div>
        </section>

        <!-- Register Popup -->
        <section id="registerPopup" class="popup">
            <div class="popup-content">
                <a href="#" class="close" aria-label="Close_Popup">&times;</a>
                <form class="form" action="register.php" method="POST">
                    <h2>Register</h2>
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" class="popup-button">Register</button>
                    <p>Already have an account? <a href="#loginPopup">Login here</a>.</p>
                </form>
            </div>
        </section>
    </header>

    <nav>
        <!-- menu.php  -->
        <ul class="menu">
            <li><a href="index.php">Home</a></li>
            <li><a href="recipes-a-main.php">Recipes</a>
                <ul class="dropdown">
                    <li><a href="recipes-most-recent.php">Most Recent</a></li>
                    <li><a href="recipes-top-rated.php">Top Rated</a></li>
                    <li><a href="recipes-favorite.php" class="disabled">Favorite</a></li>
                    <li><a href="recipes-Cuisine.php">Cuisine</a></li>
                    <li><a href="recipes-vegan.php">Vegan</a></li>
                </ul>
            </li>
            <li><a href="meals-a-main.php">Meals</a>
                <ul class="dropdown">
                    <li><a href="meals-breakfast.php">Breakfast</a></li>
                    <li><a href="meals-main-course.php">Main Course</a></li>
                    <li><a href="meals-snacks.php">Snacks</a></li>
                    <li><a href="meals-desserts.php">Desserts</a></li>
                </ul>
            </li>
            <li><a href="about-us.php">About</a></li>
            <li><a href="user-profile.php">User</a>
                <ul class="dropdown">
                    <li><a href="#registerPopup">Registration</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <!-- Logged-in user options -->
                        <li><a href="user-profile.php">Account</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <!-- Guest user options -->
                        <li><a href="login.php">Login</a></li>
                        <li><a href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </li>
        </ul>
        <!-- welcome.php -->

        <section class="banner">
            <h2 class="hero"> Discover delicious recipes,<br>
                plan your meals and <br>
                simplfy cooking</h2>
            <img src="img/banner-welcome.jpg" alt="" class="welcome-banner">
        </section>
    </nav>

    <section>

        <div class="filter-sort-container">
            <form id="filter-form" method="GET">
                <!-- Filter  -->
                <label for="category-filter">Filter by Category:</label>
                <select name="category" id="category-filter" onchange="applyFilter()">
                    <option value="">All Categories</option>
                    <?php foreach ($tags as $tag): ?>
                        <option value="<?php echo htmlspecialchars($tag['name']); ?>"
                            <?php echo isset($_GET['category']) && $_GET['category'] === $tag['name'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($tag['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- Sort -->
                <label for="sort-by">Sort By:</label>
                <select name="sort" id="sort-by" onchange="applyFilter()">
                    <option value="default" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'default' ? 'selected' : ''; ?>>Default</option>
                    <option value="newest" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'newest' ? 'selected' : ''; ?>>Newest</option>
                    <option value="popular" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'popular' ? 'selected' : ''; ?>>Most Popular</option>
                    <option value="rating" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'rating' ? 'selected' : ''; ?>>Rating (High to Low)</option>
                    <option value="likes" <?php echo isset($_GET['sort']) && $_GET['sort'] === 'likes' ? 'selected' : ''; ?>>Likes (High to Low)</option>
                </select>
                <button type="submit">Apply</button>
            </form>
        </div>
    </section>



    <main id="home">
        <?php
        // Fetch all recipes from the database
        $stmt = $pdo->prepare("SELECT * FROM recipes WHERE deleted_at IS NULL");
        $stmt->execute();
        $recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($recipes)): ?>
            <section>
                <h2 class="category">All Recipes</h2>
                <hr>
                <!-- Search result -->
                <div class="recipe-grid">
                    <div id="search-results"></div>
                </div>

                <div id="recipe-grid" class="recipe-grid">
                    <?php foreach ($recipes as $recipe): ?>
                        <article class="recipe-card">
                            <!-- Recipe Image -->
                            <img src="img/<?php echo htmlspecialchars($recipe['image_url']); ?>" alt="<?php echo htmlspecialchars($recipe['title']); ?>" class="recipe-image">

                            <!-- Recipe Title -->
                            <h4 class="recipe-head">
                                <a href="recipe.php?id=<?php echo htmlspecialchars($recipe['id']); ?>">
                                    <?php echo htmlspecialchars($recipe['title']); ?>
                                </a>
                            </h4>

                            <!-- Recipe Summary -->
                            <p class="recipe-summary">
                                <a href="recipe.php?id=<?php echo htmlspecialchars($recipe['id']); ?>">
                                    <?php echo htmlspecialchars($recipe['description']); ?>
                                </a>
                            </p>


                            <!-- Rating Section -->
                            <?php
                            $avgRating = $recipe['avg_rating'] ?? 0; // Get the average rating for the recipe (default to 0 if null)
                            $userRating = $userRatings[$recipe['id']] ?? null; // Get the user's rating for the recipe (default to null if not rated)
                            ?>
                            <div class="rating-section">
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <div class="rating-stars" data-recipe-id="<?php echo $recipe['id']; ?>">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <span class="star <?php echo ($userRating === $i || ($userRating === null && $i <= $avgRating)) ? 'active' : ''; ?>"
                                                data-rating="<?php echo $i; ?>">&#9733;</span>
                                        <?php endfor; ?>
                                    </div>
                                    <p>Average Rating: <?php echo round($avgRating, 1); ?>/5</p>
                                <?php endif; ?>
                            </div>

                            <!-- Bookmark Button -->
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <button class="bookmark-btn" data-recipe-id="<?php echo $recipe['id']; ?>">
                                    <span class="bookmark-icon">
                                        <?php
                                        $stmt = $pdo->prepare("SELECT * FROM bookmarks WHERE user_id = ? AND recipe_id = ?");
                                        $stmt->execute([$_SESSION['user_id'], $recipe['id']]);
                                        $isBookmarked = $stmt->fetch();
                                        echo $isBookmarked ? '❤️' : '♡';
                                        ?>
                                    </span>
                                </button>
                            <?php endif; ?>

                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php else: ?>
            <p>No recipes available.</p>
        <?php endif; ?>
    </main>

    <footer>
        <hr>
        <p>&copy; 2025 Lazy Chef </p>
    </footer>
</body>

</html>